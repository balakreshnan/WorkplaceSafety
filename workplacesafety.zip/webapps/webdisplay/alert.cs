﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace webdisplay
{
    public class alert
    {
        public bool person = false;
        public bool vest = false;
        public bool hardhat = false;
        public bool safetyglass = false;
    }
}